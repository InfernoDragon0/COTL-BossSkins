# Changelog

### v1.0.1
- Added Cult Bishop variants
- Added config for specifying additional skins

### v1.0.0
- Initial Release